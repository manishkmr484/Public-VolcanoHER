#!/usr/bin/env python
# _*_ coding: utf-8 _*_

import sys
import math
from scipy import constants as con
from sympy import *

script, delta_H = sys.argv

delta_H =  float(delta_H)  ##* 100 #Convvert cm-1 m-1
Tem = 298  ##* 100 #Convvert cm-1 m-1

####phy_constant
#h_p = con.h           # 6.62606957E-34 # J*s Plank Contant
h_p = 6.582119514E-16  # eV/s
#k_b = con.k           # 1.38064852E-23 # m^2 *kg*s6-2 *K-1 Boltzman Constant
k_b = 8.6173324E-5     # eV/k
#R_gas = con.R         # 8.3144598 # J*mol*-1 *K-1 Gas Constant
#l_s = con.c           # 299792458 #light speed m*s-1
#e_ele = con.e         # 1.6021766208e-19 #dian he chang shu
#Tem = 500         # Temperature 300 K
#kb_T = 0.025852   ###unit eV

#delta_H = 0      ##unit e

#######ref: Hansen, H. A., Viswanathan, V. & Nørskov, J. K. Unifying Kinetic and Thermodynamic Analysis of 2 e– and 4 e– Reduction of Oxygen on Metal Surfaces. J. Phys. Chem. C 118, 6706–6718 (2014).

##############rate constant ,dingyi###########
P = math.exp(delta_H/(k_b * Tem))

######### non-electrochemical steps######
i0 = 1/(1+P)
volcano = math.log10(i0)
print(i0,volcano)

